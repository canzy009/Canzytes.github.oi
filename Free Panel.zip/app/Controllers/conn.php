<?php

$servername = "localhost";
$dbname = "thaaxqk_kra";
$username = "thaaxqk_kra";
$password = "Ace@12345";

$conn = mysqli_connect($servername,$username,$password,$dbname);

if(!$conn) {

die(" PROBLEM WITH CONNECTION : " . mysqli_connect_error());

}
?>