<?php
include('conn.php');

    $URL = "https://nullmodhacks.online/";
    $BPShortener = $URL . "NULL";
    $CODMShortener = $URL . "CODM-DOSiyXCY0u";
    $FL84Shortener = $URL . "FL84-DOSiyXCY0u";
    $MLBBShortener = $URL . "MLBB-DOSiyXCY0u";
    $PUBGShortener = $URL . "NULL";
?>


<?= $this->extend('Layout/Starter') ?>
<?= $this->section('content') ?>
   
<div class="col-lg-6">
        <div class="card mb-3">
            <div class="card-header h6 p-3 bg-dark text-white">Shortener Links(No ads)</div>
            <div class="card-body">
            
             <div class="input-group mb-3">
  <input type="text" id="8BP" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" value= "<?php echo $BPShortener; ?>" readonly>
  <div class="input-group-append">
    <button class="btn btn-dark" type="button" onclick="copy8BP()"><i class="bi bi-clipboard"></i></button>
  </div>
</div>

<div class="input-group mb-3">
  <input type="text" id="CODM" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" value= "<?php echo $CODMShortener; ?>" readonly>
  <div class="input-group-append">
    <button class="btn btn-dark" type="button" onclick="copyCODM()"><i class="bi bi-clipboard"></i></button>
  </div>
</div>

<div class="input-group mb-3">
  <input type="text" id="FL84" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" value= "<?php echo $FL84Shortener; ?>" readonly>
  <div class="input-group-append">
    <button class="btn btn-dark" type="button" onclick="copyFL84()"><i class="bi bi-clipboard"></i></button>
  </div>
</div>

<div class="input-group mb-3">
  <input type="text" id="MLBB" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" value= "<?php echo $MLBBShortener; ?>" readonly>
  <div class="input-group-append">
    <button class="btn btn-dark" type="button" onclick="copyMLBB()"><i class="bi bi-clipboard"></i></button>
  </div>
</div>

<div class="input-group mb-3">
  <input type="text" id="PUBG" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="basic-addon2" value= "<?php echo $PUBGShortener; ?>" readonly>
  <div class="input-group-append">
    <button class="btn btn-dark" type="button" onclick="copyPUBG()"><i class="bi bi-clipboard"></i></button>
  </div>
</div>

                </div>                         
            </div>
        </div>
    </div>
    
    
    
    <div class="row">
    <div class="col-lg-12">
       
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white h6 p-3">
                Manage Shortener Links
            </div>
            <div class="card-body">

                <div class="table-responsive">
                    <table id="datatable" class="table table-bordered table-hover text-center" style="width:100%">
                        <thead>
                            <tr>
                                <th scope="row">#</th>
                                <th>8BP</th>
                                <th>CODM</th>
                                <th>FL84</th>
                                <th>MLBB</th>
                                <th>PUBG</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $fetchqry = "SELECT * FROM `Keygen_Links`";
                            $result=mysqli_query($conn,$fetchqry);
                            $num=mysqli_num_rows($result);

                            if($num > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo '<tr>';
                                    echo '<td>' . $row['id'] . '</td>';
                                    echo '<td>' . $row['8BP_Link'] . '</td>';
                                    echo '<td>' . $row['CODM_Link'] . '</td>';
                                    echo '<td>' . $row['FL84_Link'] . '</td>';
                                    echo '<td>' . $row['MLBB_Link'] . '</td>';
                                    echo '<td>' . $row['PUBG_Link'] . '</td>';
                                    echo '<td><a class="btn btn-dark btn-sm" href="Links">Edit</a></td>';
                                    echo '</tr>';
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>        
       
<script src="https://code.jquery.com/jquery-3.1.0.min.js" integrity="sha256-cCueBR6CsyA4/9szpPfrX3s49M9vUU5BgtiJj06wt/s=" crossorigin="anonymous"></script>
    <script>
  function copy8BP() {

  var UsernameText = document.getElementById("8BP");

  UsernameText.select();

  UsernameText.setSelectionRange(0, 99999);

  document.execCommand("copy");

}

function copyCODM() {

  var UsernameText = document.getElementById("CODM");

  UsernameText.select();

  UsernameText.setSelectionRange(0, 99999);

  document.execCommand("copy");

}

function copyFL84() {

  var UsernameText = document.getElementById("FL84");

  UsernameText.select();

  UsernameText.setSelectionRange(0, 99999);

  document.execCommand("copy");

}

function copyMLBB() {

  var UsernameText = document.getElementById("MLBB");

  UsernameText.select();

  UsernameText.setSelectionRange(0, 99999);

  document.execCommand("copy");

}

function copyPUBG() {

  var UsernameText = document.getElementById("PUBG");

  UsernameText.select();

  UsernameText.setSelectionRange(0, 99999);

  document.execCommand("copy");

}
    </script>
    
    
    
<?= $this->endSection() ?>