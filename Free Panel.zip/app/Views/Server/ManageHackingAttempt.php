<?= $this->extend('Layout/Starter') ?>

<?php include('conn.php'); ?>

<?= $this->section('content') ?>

<div class="row">
    <div class="col-lg-12">
       
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white h6 p-3">
                Manage <?= $title ?>
            </div>
            <div class="card-body">

                <div class="table-responsive">
                    <table id="datatable" class="table table-bordered table-hover text-center" style="width:100%">
                        <thead>
                            <tr>
                                <th scope="row">#</th>
                                <th>IP Address</th>
                                <th>IP Location</th>
                                <th>Attempt Date</th>
                                <th>Target</th>
                                <th>Status</th>
                                <th>VPN</th>
                                <th>Duration</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $fetchqry = "SELECT * FROM `visitor_logs`";
                            $result=mysqli_query($conn,$fetchqry);
                            $num=mysqli_num_rows($result);

                            if($num > 0) {
                                while($row = mysqli_fetch_assoc($result)) {
                                    echo '<tr>';
                                    echo '<td>' . $row['id'] . '</td>';
                                    echo '<td>' . $row['ip_address'] . '</td>';
                                    echo '<td>' . $row['ip_location'] . '</td>';
                                    echo '<td>' . $row['timestamp'] . '</td>';
                                    echo '<td>' . $row['visited_page'] . '</td>';
                                    echo '<td>' . $row['access_status'] . '</td>';
                                    echo '<td>' . $row['vpn_used'] . '</td>';
                                    echo '<td>' . $row['duration'] . '</td>';                                   
                                    echo '<td><a href="DeleteHackingAttempt.php?id=' . $row['id'] . '" class="btn btn-dark btn-sm"><i class="bi bi-trash"></i></a></td>';
                                    
                                    
                                    echo '</tr>';                                    
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>

<?= $this->section('css') ?>
<?= link_tag("https://cdn.datatables.net/1.10.25/css/dataTables.bootstrap5.min.css") ?>
<?= $this->endSection() ?>

<?= $this->section('js') ?>
<?= script_tag("https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js") ?>

<?= script_tag("https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap5.min.js") ?>
<script>
   
</script>
<?= $this->endSection() ?>
